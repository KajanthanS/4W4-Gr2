# Exercice 1
## Objectif: Produire un thème simple

### Le thème contiendra les éléments suivants
Un module front-page.php (la page d'accueil)
Un module single.php
Une mise en forme CSS produit à partir de plusieurs fichier Sass (.scss)

### Sur Github
Une branche exer1
Cette branche contient un minimum de 5 commits
Chaque commit est commenté de façon spécifique avec le préfixe (s2c2 ou s3c1 ou s3c2)

### Le site est déplyoé sur le serveur distant Siteground
Vous recevrez une invitation par courriel sur votre adresse « cmaisonneuve.qc.ca »

### Barème sur 5 points
Organisation de votre dépôt « 4w4 » sur github (5 commits minimum) (2 points)
Fonctionnement du thème (1 point)
Formatage sass/css du thème (2 point)