<?php  
/**
* Modèle par défaut
* 
*/
?>
<?php get_header(); ?>
<main>
    <h1> 404 - Page non disponible :(</h1>
</main>

<?php get_footer(); ?>