<footer class="site__footer">
    
    <section class="colonne1">
        <div class="texte1">
            <h5>Contact</h5>
        <p>Téléphone: (123) 456-7890</p>
        <p>Courriel: HelloWorld@gmail.com</p>
        </div>
    </section>
    
    <section class="colonne2">
        <div class="texte2">
            <h5>Liens</h5>
       <a href="https://github.com/KajanthanS">Mon Github</a>
       <a href="https://www.linkedin.com/in/kajanthan-seevarathinam-551a3a249/">Mon LinkedIn</a>
        </div>
    </section>

    <section class="colonne3">
        <div class="texte3">
            <h5>Réseaux sociaux</h5>
        <a href="https://www.facebook.com/">F</a>
        <a href="https://www.instagram.com/">I</a>
        <a href="https://twitter.com/home">T</a>
        </div>
    </section>

</footer>
<?php wp_footer(); ?>
</body>
</html>