<footer class="site__footer">
    
    <section> colonne 1</section>
    <section> colonne 2</section>
    <section> colonne 3</section>

</footer>
<?php wp_footer(); ?>
</body>
</html>