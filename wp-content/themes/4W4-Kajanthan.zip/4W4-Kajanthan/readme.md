# Laboratoire 1
## 4W4 - Conception d'interface et développement web
### Auteur: Kajanthan Seevarathinam
#### Description
- Installation local de WordPress
- Création de thème simple
- Création d'un dépôt Git local
- Création d'un dépot GitHub

##### Références
https://github.com/KajanthanS/4W4-Gr2
https://developer.wordpress.org/themes/
