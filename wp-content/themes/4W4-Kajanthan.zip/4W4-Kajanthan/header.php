<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta http-equiv="X-UA-Compatible" content="IE=edge">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">

    <link rel="stylesheet" href="https://fonts.googleapis.com/css2?family=Material+Symbols+Outlined:opsz,wght,FILL,GRAD@48,400,0,0" />

    <?php wp_head(); ?>
</head>
<?php 
$nouvelle_classe = "";
if(is_front_page())(
    $nouvelle_classe = "no-aside"
)
?>

<body class="site <?php echo (is_front_page()?'no-aside':'');?>">
<!-- <body class="site <?= $nouvelle_classe; ?> -->
   <header class="site__header">
    <section class="site__header__logo">
         <?php the_custom_logo() ?> 
        <div class="menu__recherche">
            <input type="checkbox" id="check-menu">
            <?php wp_nav_menu(array(
                "menu" => "entete",
                "container" => "nav"
                )) ?>
            
            <!-- <h3 class="icon-burger"><span class="material-symbols-outlined">menu</span></h3> -->
            <label class="icon-burger" for="check-menu"><img src="https://s2.svgbox.net/loaders.svg?ic=hearts&color=ffffff" width="40" height="40"></label>
            <?php get_search_form() ?>
            
        </div>
    </section>
    <h1><a href="<?= bloginfo('url') ?>"><?= bloginfo('name') ?></a></h1>
    <h2><?= bloginfo('description') ?></h2>
   </header>
   <?php 
    if ( ! is_front_page()){
    get_template_part("template-parts/aside"); 
    }
    ?>
