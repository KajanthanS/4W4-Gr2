<?php  ?>
<!-- /**
 * template part pour afficher la galerie dans la page d'accueil
 */ -->
 
 <article class="blocflex__galerie">
    <?php the_content(); ?>
 </article>

 